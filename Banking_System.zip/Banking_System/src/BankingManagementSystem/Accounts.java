package BankingManagementSystem;

import java.sql.Connection;
import java.util.Scanner;
public class Accounts {
	private Connection connection;
	private Scanner scanner;
	Accounts(Connection connection, Scanner scanner){
		this.connection=connection;
		this.scanner=scanner;
	}	
	public long open_account(String email) {
		
			scanner.nextLine();
			System.out.println("Enter Full name: ");
			String full_name=scanner.nextLine();
			System.out.println("Enter initial amount: ");
			double balance=scanner.nextDouble();
			scanner.nextLine();
			System.out.println("Enter Security Pin: ");
			String security_pin=scanner.nextLine();
		
		return 0;
	}
	public long get_account_number(String email) {
		return 0;
	}
	public long generate_account_number() {
		return 0;
	}
	public boolean account_exist() {
		return false;
	}

}
