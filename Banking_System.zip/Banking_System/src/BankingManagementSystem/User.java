package BankingManagementSystem;
import java.util.Scanner;
import java.sql.Connection;
public class User {
	private Connection connection;
	private Scanner scanner;
	public User(Connection connection, Scanner scanner){
		this.connection=connection;
		this.scanner=scanner;
	}

	public void register() {
		scanner.nextLine();
		System.out.println("Full name: ");
		String fullname=scanner.nextLine();
		System.out.println("Email: ");
		String email=scanner.nextLine();
		System.out.println("Password: ");
		String password=scanner.nextLine();
		if(user_exist(email)) {
			System.out.println("User Already Exists for this Email Address!!");
			return;
		}
	}
	public String login() {
		scanner.nextLine();
		System.out.println("Email: ");
		String email=scanner.nextLine();
		System.out.println("Password: ");
		String password=scanner.nextLine();
		return null;
	}
	public boolean user_exist(String email) {
		return false;
	}

}
