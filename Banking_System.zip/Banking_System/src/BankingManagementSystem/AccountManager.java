package BankingManagementSystem;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
public class AccountManager {
	private Connection connection;
	private Scanner scanner;
	AccountManager(Connection connection, Scanner scanner){
		this.connection=connection;
		this.scanner=scanner;
	}
	public void credit_money(long account_number) throws SQLException {
		scanner.nextLine();
		System.out.println("Enter Amount: ");
		double amount=scanner.nextDouble();
		scanner.nextLine();
		System.out.println("Enter Security Pin: ");
		String security_pin=scanner.nextLine();
		
		
		
	}
	public void debit_money(long account_number) throws SQLException {
		scanner.nextLine();
		System.out.println("Enter amount: ");
		double amount=scanner.nextDouble();
		scanner.nextLine();
		System.out.println("Enter Security Pin: ");
		String security_pin=scanner.nextLine();
		
	}
	public void transfer_money(long sender_account_number) throws SQLException {
		scanner.nextLine();
		System.out.println("Enter Receiver Account Number: ");
		long receiver_account_number=scanner.nextLong();
		System.out.println("Enter Amount: ");
		double amount=scanner.nextDouble();
		scanner.nextLine();
		System.out.println("Enter Security Pin: ");
		String security_pin=scanner.nextLine();
		
	}
	public void check_balance() {
		scanner.nextLine();
		System.out.println("Enter Security Pin: ");
		String security_pin=scanner.nextLine();
	}

}
